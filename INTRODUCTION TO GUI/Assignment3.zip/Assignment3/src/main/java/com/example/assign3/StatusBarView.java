// EMMANUELLA EYO 11291003 EEE917
package com.example.assign3;
import javafx.scene.control.Label;
import javafx.scene.control.ToolBar;
import java.util.List;

public class StatusBarView extends ToolBar implements Subscriber {

    private int createdCount = 0;
    private int deletedCount = 0;
    private int total = 0;
    Label state;

    public StatusBarView() {
        state = new Label("Created: " + createdCount + " Deleted: " + deletedCount + " Total: " + total );
        this.getItems().add(state);
    }

    @Override
    public void receiveNotification(String channel, List<Box> boxes) {
        if ("create".equals(channel)) {
            createdCount +=1;
            total +=1;
        } else if ("delete".equals(channel)) {
            deletedCount+=1;
            total -=1;
        }
        updateStatusBar();
    }
    private void updateStatusBar() {
        state.setText("Created: " + createdCount + "   Deleted: " + deletedCount + "   Total: " + total);
    }


}


