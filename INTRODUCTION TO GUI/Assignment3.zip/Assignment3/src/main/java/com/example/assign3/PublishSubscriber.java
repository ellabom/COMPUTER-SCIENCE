// EMMANUELLA EYO 11291003 EEE917
package com.example.assign3;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PublishSubscriber {

    private Map<String, ArrayList<Subscriber>> subChannels;

    public PublishSubscriber(){
        this.subChannels = new HashMap<>();
    }

    //create new channel
    public void newChannel(String key){
        if (!subChannels.containsKey(key)) {
            subChannels.put(key, new ArrayList<>());
        }
    }

    //allow publishers to and publish to a channel
    public void publish(String channel, List<Box> boxes){
        List<Subscriber> subs = subChannels.get(channel);

        if(subs != null) {
            for (Subscriber sub : subs) {
                sub.receiveNotification(channel, boxes);
            }
        }
    }


    // Subscribers should have a method to receive a notification
    public void addSubscribe(String channelKey, Subscriber subscriber) {
        if (subChannels.containsKey(channelKey)) {
            // If the channel already exists, add the new subscriber to the existing list
            subChannels.get(channelKey).add(subscriber);
        } else {
            // If the channel does not exist, create a new list and add the subscriber
            ArrayList<Subscriber> subscribers = new ArrayList<>();
            subscribers.add(subscriber);
            subChannels.put(channelKey, subscribers);
        }
    }

    public void removeSubscriber(String channel, Subscriber subscriber) {
        if (subChannels.containsKey(channel)) {
            subChannels.get(channel).remove(subscriber);
        }
    }
}
