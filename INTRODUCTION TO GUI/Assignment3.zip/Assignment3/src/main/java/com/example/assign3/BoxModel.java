// EMMANUELLA EYO 11291003 EEE917
package com.example.assign3;


import java.util.ArrayList;

public class BoxModel {

    private PublishSubscriber publishSubscriber;
    private ArrayList<Subscriber> subs;
    private ArrayList<Box> boxes;

    public BoxModel(){
        subs = new ArrayList<Subscriber>();
        boxes = new ArrayList<Box>();
    }

    public void addBox(double x, double y, double size){
        Box newBox = new Box(x, y, size);
        boxes.add(newBox);
        notifySubscriber("create");
    }

    public void setPublishSubscriber(PublishSubscriber publishSubscriber) {
        this.publishSubscriber = publishSubscriber;
    }

    public PublishSubscriber getPublishSubscriber() {
        return publishSubscriber;
    }

    public void addSubscriber(String channel, Subscriber sub) {
        subs.add(sub);
        publishSubscriber.addSubscribe(channel, sub);
    }

    public void notifySubscriber(String channel){
        publishSubscriber.publish(channel, boxes);
    }

    public ArrayList<Box> getBoxes() {
        return boxes;
    }
    public ArrayList<Box> getSelected(){
        ArrayList<Box> selected = new ArrayList<>();
        for(Box b : boxes){
            if(b.isSelected()){
                selected.add(b);
            }
        }
        return selected;
    }


    public Box getNextBox(int currentPosition) {
        if (this.boxes == null || this.boxes.isEmpty()) {
            return null; // or handle the empty case in some way
        }
        int nextIndex = (currentPosition + 1) % this.boxes.size();
        return this.boxes.get(nextIndex);
    }

    public void removeBox(Box b){
        boxes.remove(b);
        notifySubscriber("delete");
    }

    public void clearBoxes(){
        boxes.clear();
    }

    public void moveBox(double dx, double dy){
        for(Box box : boxes){
            if(box.isSelected()){
                box.setX(dx + box.getX());
                box.setY(dy + box.getY());
            }
        }
        notifySubscriber("update");
    }

}
