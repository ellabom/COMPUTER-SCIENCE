// EMMANUELLA EYO 11291003 EEE917
package com.example.assign3;

import javafx.scene.input.KeyEvent;
import java.util.*;

public class AppController {
    private BoxModel boxModel;
    private InteractionModel iModel;
    private enum interactionState {
        DEFAULT, CURSOR_SELECT_MANIPULATE, PRESS_HOTKEY
    }
    private interactionState state = interactionState.DEFAULT;
    private Timer myTimer;
    private boolean controlIsPressed;
    public void setModel(BoxModel boxModel) {
        this.boxModel = boxModel;
    }

    public void setIModel(InteractionModel iModel) {
        this.iModel = iModel;
    }

    public void handleKeyPress(KeyEvent event) {
        int currentPositionIndex = iModel.getCurrentPositionIndex();
        switch (state) {
            case DEFAULT -> {
                handleDefaultState(event, currentPositionIndex);
            }
            case CURSOR_SELECT_MANIPULATE -> {
                handleCursorSelectManipulateState(event);
                state = interactionState.DEFAULT;}
            case PRESS_HOTKEY -> {
                //state = interactionState.DEFAULT;
            }
        }
    }


    public void handleKeyReleased(KeyEvent event) {
        if (event.isControlDown() && myTimer != null) {
            myTimer.cancel();
            controlIsPressed = false;
            myTimer = null;
        }
    }

    public void handleControlKeyPressed(KeyEvent event) {
        if (event.isControlDown()) {
            myTimer = new Timer();
            myTimer.schedule(new TimerTask() {
                @Override
                public void run() {
                    showGuide();
                    controlIsPressed = true;
                }
            }, 1000);
        }
    }

    private void showGuide() {
        //DISPLAY SHOW KEY
    }


    private void handlePressHotkeyState(KeyEvent event) {
        if (controlIsPressed && event.isShortcutDown()) {
            // Handle the hotkey based on the event code
            switch (event.getCode()) {
              //

            }
        }
        state = interactionState.DEFAULT;
    }



    private void handleDefaultState(KeyEvent event, int currentPositionIndex) {
        switch (event.getCode()) {
            case TAB ->{

                state = interactionState.DEFAULT;

                // Get the next box
                Box nextBox = boxModel.getNextBox(currentPositionIndex);
                moveCursorToBox(nextBox);  // Move the cursor

                int entitiesSize = boxModel.getBoxes().size();
                if (entitiesSize > 0) {
                    int newCursorPosition = (currentPositionIndex + 1) % entitiesSize;
                    iModel.setCurrentPositionIndex(newCursorPosition);
                    iModel.setCursorBox(boxModel.getBoxes().get(iModel.getCurrentPositionIndex()));

                }
            }
            case UP -> {
                // Get the current cursor position
                Box currentCursorBox = boxModel.getBoxes().get(currentPositionIndex);

                // Find the box above the current cursor position
                Box aboveBox = getAboveBox(currentCursorBox);

                if (aboveBox != null) {
                    // Move the cursor to the box above
                    moveCursorToBox(aboveBox);

                    // Update the new cursor position index
                    int newPosition = boxModel.getBoxes().indexOf(aboveBox);
                    iModel.setCurrentPositionIndex(newPosition);
                    iModel.setCursorBox(aboveBox);
                }
            }
            case DOWN -> {
                // Move the cursor to the box below the current position
                Box currentBox = boxModel.getBoxes().get(currentPositionIndex);
                Box belowBox = getBelowBox(currentBox);

                if (belowBox != null) {
                    moveCursorToBox(belowBox);

                    // Update the cursor position index
                    int newPosition = boxModel.getBoxes().indexOf(belowBox);
                    iModel.setCurrentPositionIndex(newPosition);
                    iModel.setCursorBox(belowBox);
                }
            }
            case LEFT -> {
                // Move the cursor to the box on the left of the current position
                Box leftBox = getLeftBox(boxModel.getBoxes().get(currentPositionIndex));
                if (leftBox != null) {
                    moveCursorToBox(leftBox);

                    // Update the cursor position index
                    int newPosition = boxModel.getBoxes().indexOf(leftBox);
                    iModel.setCurrentPositionIndex(newPosition);
                    iModel.setCursorBox(leftBox);
                }
            }
            case RIGHT -> {
                // Move the cursor to the box on the right of the current position
                Box rightBox = getRightBox(boxModel.getBoxes().get(currentPositionIndex));

                if (rightBox != null) {
                    moveCursorToBox(rightBox);

                    // Update the cursor position index
                    int newPosition = boxModel.getBoxes().indexOf(rightBox);
                    iModel.setCurrentPositionIndex(newPosition);
                    iModel.setCursorBox(rightBox);
                }
            }
            case CONTROL -> {
                state = interactionState.CURSOR_SELECT_MANIPULATE;
            }
            default -> {
                state = interactionState.DEFAULT;
            }
        }
    }


    private void handleCursorSelectManipulateState(KeyEvent event) {
        switch (event.getCode()) {
            case C -> handleControlC(event);
            case S -> handleControlS(event);
            case A -> handleControlA(event);
            case D -> handleControlD(event);
            case LEFT -> handleControlLeft(event);
            case RIGHT -> handleControlRight(event);
            case UP -> handleControlUp(event);
            case DOWN -> handleControlDown(event);
            case U -> handleControlU(event);
            case J -> handleControlJ(event);
            case L -> handleControlL(event);
            case R -> handleControlR(event);
            case T -> handleControlT(event);
            case B -> handleControlB(event);
            case H -> handleControlH(event);
            case V -> handleControlV(event);
            default -> {
                state = interactionState.DEFAULT;
            }
        }
    }


    /**
     * For the selected boxes, align the left edges of the selected objects to the left edge of
     * the object under the cursor (if there is one);
     * if not, align to the edge of the first object in the selection
     *
     * @param event The KeyEvent.
     */
    private void handleControlL(KeyEvent event) {
        if(event.isControlDown()){

            List<Box> selected = boxModel.getSelected();

            if (selected.isEmpty()) {
                return; // No selected boxes to align
            }

            Box targetBox = iModel.getCursorBox();
            if (targetBox == null) {
                targetBox = selected.get(0);
            }

            for (Box box : selected) {
                box.setX(targetBox.getX());

            }
            boxModel.notifySubscriber("update");
        }

    }

    /**
     * For the selected boxes, align the right edges of the selected objects to the top right of
     * the object under the cursor (if there is one);
     * if not, align to the edge of the first object in the selection
     *
     * @param event The KeyEvent.
     */
    private void handleControlR(KeyEvent event) {
        if(event.isControlDown()){

            List<Box> selected = boxModel.getSelected();

            if (selected.isEmpty()) {
                return; // No selected boxes to align
            }

            Box targetBox = iModel.getCursorBox();
            if (targetBox == null) {
                targetBox = selected.get(0);
            }

            double rightEdge = targetBox.getX() + targetBox.getSize();
            for (Box box : selected) {
                box.setX(rightEdge - box.getSize());

            }
            boxModel.notifySubscriber("update");
        }
    }


    /**
     * For the selected boxes, align the bottom edges of the selected objects to the bottom edge of
     * the object under the cursor (if there is one);
     * if not, align to the edge of the first object in the selection
     *
     * @param event The KeyEvent.
     */
    private void handleControlB(KeyEvent event) {
        if(event.isControlDown()){
            List<Box> selected = boxModel.getSelected();

            if (selected.isEmpty()) {
                return; // No selected boxes to align
            }

            Box targetBox = iModel.getCursorBox();
            if (targetBox == null) {
                targetBox = selected.get(0);
            }

            double topEdge = targetBox.getY();
            for (Box box : selected) {
                box.setY(topEdge);
            }
        }
        boxModel.notifySubscriber("update");


    }

    /**
     * For the selected boxes, align the top edges of the selected objects to the top edge of
     * the object under the cursor (if there is one);
     * if not, align to the edge of the first object in the selection
     *
     * @param event The KeyEvent.
     */
    private void handleControlT(KeyEvent event) {
        if(event.isControlDown()){
            List<Box> selected = boxModel.getSelected();

            if (selected.isEmpty()) {
                return; // No selected boxes to align
            }

            Box targetBox = iModel.getCursorBox();
            if (targetBox == null) {
                targetBox = selected.get(0);
            }

            double bottomEdge = targetBox.getY() + targetBox.getSize();
            for (Box box : selected) {
                box.setY(bottomEdge - box.getSize());
            }
        }
        boxModel.notifySubscriber("update");
    }


    /**
     * when Ctrl-C is pressed, create a new box.
     *
     * @param event The KeyEvent.
     */
    private void handleControlC(KeyEvent event) {
        if (event.isControlDown()) {
            double x = boxModel.getBoxes().size() * 50 + 100;
            double y = boxModel.getBoxes().size() * 50 + 100;
            boxModel.addBox(x, y, 100);
        }

    }

    /**
     * Toggles the selection state of the current box when the control key is pressed.
     * And notifies subscribers.
     *
     * @param event The KeyEvent.
     */
    private void handleControlS(KeyEvent event) {
        if (event.isControlDown()) {
            Box currentBox = iModel.getCursorBox();
            if (currentBox != null) {
                currentBox.setSelected(!currentBox.isSelected());
                iModel.setCursorBox(currentBox);
                boxModel.notifySubscriber("selection");
            }
        }
    }

    /**
     * Toggles the selection state of all boxes when the control key is pressed.
     * and notifies subscribers.
     *
     * @param event The KeyEvent.
     */
    private void handleControlA(KeyEvent event) {
        if (event.isControlDown()) {
            for (Box box : boxModel.getBoxes()) {
                box.setSelected(!box.isSelected());
            }
            boxModel.notifySubscriber("selection");
        }
    }

    /**
     * Removes selected boxes or clears all boxes if all are selected when key is pressed.
     *
     * @param event The KeyEvent.
     */
    private void handleControlD(KeyEvent event) {
        if (event.isControlDown()) {
            boolean allSelected = boxModel.getBoxes().stream().allMatch(Box::isSelected);

            if (allSelected) {
                boxModel.clearBoxes(); // Remove all objects
            } else {
                ArrayList<Box> entitiesCopy = new ArrayList<>(boxModel.getBoxes());

                for (Box b : entitiesCopy) {
                    if (b.isSelected()) {
                        boxModel.removeBox(b);
                    }
                }
            }
            moveCursorToBox(iModel.getCursorBox());
        }
    }


    /**
     * Moves the selected box or all boxes to the left by a fixed distance
     * and Notifies subscribers about the update.
     *
     * @param event The KeyEvent.
     */
    private void handleControlLeft(KeyEvent event) {
        if (event.isControlDown()) {
            boxModel.moveBox(-15, 0);
        }
    }

    /**
     * Moves the selected box or all boxes to the right by a fixed distance
     * and Notifies subscribers about the update.
     *
     * @param event The KeyEvent.
     */
    private void handleControlRight(KeyEvent event) {
        if (event.isControlDown()) {
            boxModel.moveBox(15, 0);
        }
    }

    /**
     * Moves the selected box or all boxes to the up by a fixed distance
     * and Notifies subscribers about the update.
     *
     * @param event The KeyEvent.
     */
    private void handleControlUp(KeyEvent event) {
        if (event.isControlDown()) {
            boxModel.moveBox(0, -15);
        }
    }

    /**
     * Moves the selected box or all boxes to the down by a fixed distance
     * and Notifies subscribers about the update.
     *
     * @param event The KeyEvent.
     */
    private void handleControlDown(KeyEvent event) {
        if (event.isControlDown()) {
            boxModel.moveBox(0, 15);
        }
    }

    /**
     * Increases the size of selected boxes. Notifies subscribers about the update.
     *
     * @param event The KeyEvent.
     */

    private void handleControlU(KeyEvent event) {
        if (event.isControlDown()) {
            for (Box b : boxModel.getBoxes()) {
                if (b.isSelected()) {
                    b.increaseSize(5);
                }
            }
            boxModel.notifySubscriber("update");
        }
    }

    private void handleControlJ(KeyEvent event) {
        if (event.isControlDown()) {
            for (Box b : boxModel.getBoxes()) {
                if (b.isSelected()) {
                    b.decreaseSize(5);
                }
            }
            boxModel.notifySubscriber("update");
        }
    }

    private void handleControlH(KeyEvent event) {
        if (event.isControlDown()) {

            // get selected boxes
            List<Box> selected = boxModel.getSelected();

            if (selected.isEmpty()) {
                return;
            }

            // Sort the selected boxes by their X coordinates
            selected.sort(Comparator.comparingDouble(Box::getX));

            // Find the left and right edges
            double leftmostEdge = selected.get(0).getX();
            double rightmostEdge = selected.get(selected.size() - 1).getX() + selected.get(selected.size() - 1).getSize();

            double width = rightmostEdge - leftmostEdge;
            double space = width / (selected.size() - 1);

            double currentX = leftmostEdge;
            for (Box b : selected) {
                b.setX(currentX);
                currentX += b.getSize() + space;
            }
            boxModel.notifySubscriber("update");
        }
    }


    private void handleControlV(KeyEvent event) {
        if (event.isControlDown()) {
            // Get the selected list
            List<Box> selectedBoxes = boxModel.getSelected();

            if (selectedBoxes.isEmpty()) {
                return; // No selected boxes to distribute
            }

            // Sort the selected boxes by their Y coordinates
            selectedBoxes.sort(Comparator.comparingDouble(Box::getY));

            // Calculate the total height of the selected objects
            double totalHeight = selectedBoxes.get(selectedBoxes.size() - 1).getY() +
                    selectedBoxes.get(selectedBoxes.size() - 1).getSize() - selectedBoxes.get(0).getY();

            // Calculate the equal spacing between objects
            double equalSpacing = totalHeight / (selectedBoxes.size() - 1);

            // Distribute objects evenly
            double currentY = selectedBoxes.get(0).getY();
            for (Box selectedBox : selectedBoxes) {
                selectedBox.setY(currentY);
                currentY += selectedBox.getSize() + equalSpacing;
            }

            boxModel.notifySubscriber("update");
        }
    }


    /**
     * Moves the cursor to the specified box and notifies subscribers about the update.
     * @param targetBox The target Box to move the cursor to.
     */
    public void moveCursorToBox(Box targetBox) {
        // Deselect the current object (if it exists)
        List<Box> boxes = boxModel.getBoxes();
        int currentPosition = boxes.indexOf(targetBox);

        if(currentPosition == -1){
            iModel.setCursorBox(boxes.get(0));
        }
        iModel.setCursorBox(targetBox);

        // Notify about the cursor movement
        boxModel.notifySubscriber("update");
    }

    public Box getAboveBox(Box cursorObject){
        List<Box> boxes = boxModel.getBoxes();
        Box aboveObject = null;
        double min = 10000;

        for (Box topBox : boxes) {
            if (!topBox.equals(cursorObject) && topBox.getY() < cursorObject.getY()) {
                double distance = cursorObject.getY() - topBox.getY();

                if (distance < min) {
                    min = distance;
                    aboveObject = topBox;
                }
            }
        }


        return aboveObject;
    }
    public Box getBelowBox(Box cursorObject){
        List<Box> boxes = boxModel.getBoxes();
        Box belowObject = null;
        double minDistance = 10000;

        for (Box box : boxes) {
            if (!box.equals(cursorObject) && box.getY() > cursorObject.getY()) {
                double distance = box.getY() - cursorObject.getY();

                if (distance < minDistance) {
                    minDistance = distance;
                    belowObject = box;
                }
            }
        }

        return belowObject;
    }

    // find the box, left of the current object in the
    // horizontal dimension,
    public Box getLeftBox(Box cursorObject) {
        List<Box> boxes = boxModel.getBoxes();
        Box leftObject = null;
        double minDistance = 10000;

        for (Box box : boxes) {
            if (box.getX() < cursorObject.getX()) {
                double distance = cursorObject.getX() - box.getX();

                if (distance < minDistance) {
                    minDistance = distance;
                    leftObject = box;
                }
            }
        }

        return leftObject;
    }

    // find the box, right of the current object in the
    // horizontal dimension,
    public Box getRightBox(Box cursorObject) {
        List<Box> boxes = boxModel.getBoxes();
        Box rightObject = null;
        double minDistance = 10000;

        for (Box box : boxes) {
            if (box.getX() > cursorObject.getX()) {
                double distance = box.getX() - cursorObject.getX();

                if (distance < minDistance) {
                    minDistance = distance;
                    rightObject = box;
                }
            }
        }
        return rightObject;
    }


}
