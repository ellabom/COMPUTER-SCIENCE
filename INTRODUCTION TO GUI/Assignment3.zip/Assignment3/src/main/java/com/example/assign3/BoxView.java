// EMMANUELLA EYO 11291003 EEE917
package com.example.assign3;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;

import java.util.List;

public class BoxView extends BorderPane implements Subscriber {

    Canvas canvas;
    GraphicsContext gc;
    InteractionModel interactionModel;

    public BoxView(){
        canvas = new Canvas(800, 800);
        gc = canvas.getGraphicsContext2D();
        this.getChildren().add(canvas);
    }


    public void draw(List<Box> entities, Box cursorPosition, boolean highlightObject) {

        gc.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());

        for (Box box : entities) {
            double x = box.getX();
            double y = box.getY();
            double size = box.getSize();

            // Default color
            Color boxColor = Color.valueOf("#609EA0");

            // Check if the box is the cursor position and should be highlighted
            if (box.equals(cursorPosition) && highlightObject) {
                boxColor = Color.ORANGERED; // Highlight cursor position in a different color
            }

            // Check if the box is selected and apply a yellow border
            if (box.isSelected()) {
                boxColor = Color.ORANGERED; // Use a different color for selected boxes
                gc.setStroke(Color.YELLOW);
                gc.setLineWidth(5);
            }
            else {
                gc.setStroke(Color.valueOf("#156FB3"));
                gc.setLineWidth(2);
            }

            gc.setFill(boxColor);
            gc.fillRect(x, y, size, size);
            gc.strokeRect(x, y, size, size);
        }
    }

    public void setInteractionModel(InteractionModel interactionModel) {
        this.interactionModel = interactionModel;
    }

    @Override
    public void receiveNotification(String channel, List<Box> boxes) {
        if (channel.equals("create")) {
            draw(boxes, null, false);
        } else if (channel.equals("delete")) {
            draw(boxes, null, false);
        }else if (channel.equals("update")) {
            draw(boxes, interactionModel.getCursorBox(), true);
        }else if (channel.equals("selection")) {
            draw(boxes, interactionModel.getCursorBox(), true);
        }
    }


}
