// EMMANUELLA EYO 11291003 EEE917
package com.example.assign3;

import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.control.ToolBar;
import javafx.scene.layout.BorderPane;


public class MainUI extends BorderPane{
    public MainUI() {
        // create MVC components
        BoxModel boxModel = new BoxModel();
        BoxView view = new BoxView();
        AppController controller = new AppController();
        InteractionModel interactionModel = new InteractionModel();
        PublishSubscriber publishSubscriber = new PublishSubscriber();
        StatusBarView statusBarView = new StatusBarView();


        // link them together
        controller.setModel(boxModel);
        controller.setIModel(interactionModel);
        boxModel.setPublishSubscriber(publishSubscriber);
        view.setInteractionModel(interactionModel);

        publishSubscriber.newChannel("create");
        publishSubscriber.newChannel("delete");
        publishSubscriber.newChannel("update");
        publishSubscriber.newChannel("selection");

        publishSubscriber.addSubscribe("create", view);
        publishSubscriber.addSubscribe("delete", view);
        publishSubscriber.addSubscribe("update", view);
        publishSubscriber.addSubscribe("selection", view);

        publishSubscriber.addSubscribe("create", statusBarView);
        publishSubscriber.addSubscribe("delete", statusBarView);

        setOnKeyPressed(controller::handleKeyPress);

        // Place the view in the center and the statusBarView at the bottom

        this.setCenter(view);
        this.setBottom(statusBarView);
        this.setPadding(new Insets(0));

    }
}
