// EMMANUELLA EYO 11291003 EEE917
package com.example.assign3;

public class InteractionModel {

    private Box cursorBox;
    private int currentPositionIndex;

    public InteractionModel(){
        cursorBox = null;
        currentPositionIndex = -1;
    }

    public void setCursorBox(Box cursorBox) {
        this.cursorBox = cursorBox;
    }

    public Box getCursorBox() {
        return cursorBox;
    }

    public void setCurrentPositionIndex(int currentPositionIndex) {
        this.currentPositionIndex = currentPositionIndex;
    }

    public int getCurrentPositionIndex() {
        return currentPositionIndex;
    }
}
