// EMMANUELLA EYO 11291003 EEE917
package com.example.assign3;

public class Box {

    private double x, y, size;
    private boolean isSelected;

    public Box(double x, double y, double size){
        this.x = x;
        this.y = y;
        this.size = size;
        this.isSelected = false;
    }

    public double getX() {
        return x;
    }
    public double getY() {
        return y;
    }
    public void setY(double y) {
        this.y = y;
    }
    public void setX(double x) {
        this.x = x;
    }
    public double getSize() {
        return size;
    }
    public void setSize(double size) {
        this.size = size;
    }
    public void increaseSize(double increase){this.size += increase;}
    public void decreaseSize(double increase){this.size -= increase;}

    public void setSelected(boolean selected) {
        isSelected = selected;
    }

    public boolean isSelected() {
        return isSelected;
    }
}