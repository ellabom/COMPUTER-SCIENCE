// EMMANUELLA EYO 11291003 EEE917
package com.example.assign3;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class EditorApp extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {

        MainUI root = new MainUI();
        root.setStyle("-fx-background-color: #023020");
        Scene scene = new Scene(root, 800, 800);
        primaryStage.setTitle("381-A3");
        primaryStage.setScene(scene);
        primaryStage.show();
        root.requestFocus();

    }
}
