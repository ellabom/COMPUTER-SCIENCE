// EMMANUELLA EYO 11291003 EEE917
package com.example.assign3;

import java.util.List;

public interface Subscriber {
    public void receiveNotification(String channel, List<Box> boxes);
}
