module com.example.assign3 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.assign3 to javafx.fxml;
    exports com.example.assign3;
}