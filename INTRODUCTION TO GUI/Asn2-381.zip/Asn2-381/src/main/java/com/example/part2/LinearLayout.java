package com.example.part2;

import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

import java.util.ArrayList;
import java.util.List;

public class LinearLayout {

    private List<SimWidget> children;
    private Rectangle rectangle;

    private double visWidth;
    private double visHeight;

    public LinearLayout(){
        children = new ArrayList<>();
        rectangle = new Rectangle();
        rectangle.setStrokeWidth(10);
        rectangle.setStroke(Color.DARKBLUE);
    }


    protected void setColor(Color linearColor){
        rectangle.setFill(linearColor);
    }


    public void doLayout(double width, double height) {

        calculateVIS();
        doHorizontalLayout(0, width);
        doVerticalLayout(0, height);

        rectangle.setWidth(width);
        rectangle.setHeight(height);
    }



    public void calculateVIS(){
        visWidth = 0;
        visHeight = 0;
        for(SimWidget child: children){
            visWidth += child.getMinWidth();
            visHeight = Math.max(visHeight, child.getPrefHeight());
        }

        rectangle.setWidth(visWidth);
        rectangle.setHeight(visHeight);
    }

    public void doHorizontalLayout(double parcelLeft, double parcelRight) {
        double remainingWidth = Math.abs(parcelLeft - parcelRight);
        double equalAllocation = remainingWidth / children.size();
        double height = 0;
        double left = parcelLeft;
        for (SimWidget child : children) {
            double childrenWidth = child.getMinWidth() + equalAllocation;
            childrenWidth = Math.min(childrenWidth, child.getMaxWidth());
            child.doHorizontalLayout(left, left + childrenWidth);
            height = Math.max(height, child.getPrefHeight());
            left += childrenWidth;
        }

        rectangle.setWidth(remainingWidth);
        rectangle.setHeight(height);
    }

    public void doVerticalLayout(double parcelTop, double parcelBottom){
        for (SimWidget child : children){
            child.doVerticalLayout(parcelTop, parcelBottom);
        }

    }


    public void addChild(SimWidget child){
        children.add(child);
    }
    public List<SimWidget> getChildren() {
        return children;
    }

    public Rectangle getRectangle() {
        return rectangle;
    }
}
