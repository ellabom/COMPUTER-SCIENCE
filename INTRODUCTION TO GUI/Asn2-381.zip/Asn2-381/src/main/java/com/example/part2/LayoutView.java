package com.example.part2;

import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;

public class LayoutView extends Pane {
    private LinearLayout root;

    public LayoutView(){
        root = new LinearLayout();
        root.setColor(Color.ORANGE);

        SimWidget sw1 = new SimWidget(50,200,200, SimWidget.VerticalPosition.MIDDLE);
        SimWidget sw2 = new SimWidget(100,800,100, SimWidget.VerticalPosition.TOP);
        SimWidget sw3 = new SimWidget(50,150,150, SimWidget.VerticalPosition.FILL);

        root.addChild(sw1);
        root.addChild(sw2);
        root.addChild(sw3);

        this.widthProperty().addListener(observable -> root.doLayout(this.getWidth(), this.getHeight()));
        this.heightProperty().addListener(observable -> root.doLayout(this.getWidth(), this.getHeight()));


        this.addRectangles(root);
    }

    public void addRectangles(LinearLayout root) {
        // Add layout container and child widget rectangles to the LayoutView
        getChildren().add(root.getRectangle());
        for (SimWidget child : root.getChildren()) {
            getChildren().add(child.getWidgetRectangle());
        }
    }
}
