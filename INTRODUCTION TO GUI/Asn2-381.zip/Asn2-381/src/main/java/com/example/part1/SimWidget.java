package com.example.part1;

import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

public class SimWidget {
    private double minWidth, maxWidth, prefHeight;
    private double myLeft, myTop, myHeight, myWidth;

    private Rectangle widgetRectangle;

    public SimWidget(double minWidth, double maxWidth, double prefHeight){
        this.minWidth = minWidth;
        this.maxWidth = maxWidth;
        this.prefHeight = prefHeight;

        this.myLeft = 0;
        this.myTop = 0;
        this.myWidth = minWidth;
        this.myHeight = prefHeight;

        widgetRectangle = new Rectangle(myLeft, myTop, myWidth,myHeight);
        widgetRectangle.setFill(Color.YELLOW);
        widgetRectangle.setStroke(Color.BLACK);

    }

    // getters
    public double getMinWidth(){
        return minWidth;
    }
    public double getMaxWidth() {
        return maxWidth;
    }
    public double getPrefHeight() {
        return prefHeight;
    }
    public double getMyHeight() {
        return myHeight;
    }
    public double getMyWidth() {
        return myWidth;
    }

    //setters
    public void setPrefHeight(double prefHeight) {
        this.prefHeight = prefHeight;
    }
    public void setMaxWidth(double maxWidth) {
        this.maxWidth = maxWidth;
    }
    public void setMinWidth(double minWidth) {
        this.minWidth = minWidth;
    }
    public void setMyHeight(double myHeight) {

        this.myHeight = myHeight;
        widgetRectangle.setHeight(myHeight);
    }
    public void setMyWidth(double myWidth) {
        this.myWidth = myWidth;
        widgetRectangle.setWidth(myWidth);
    }

    public void setMyLeft(double myLeft) {
        this.myLeft = myLeft;
        widgetRectangle.setX(myLeft);
    }

    public void setMyTop(double myTop) {
        this.myTop = myTop;
        widgetRectangle.setY(myTop);
    }

    public Rectangle getWidgetRectangle(){
        return widgetRectangle;
    }

}

