package com.example.part3;

import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;

public class LayoutView extends Pane {
    private LinearLayout root;

    public LayoutView() {
        root = new LinearLayout();
        root.setColor(Color.LIGHTBLUE);
        SimWidget sw1 = new SimWidget(50, 200, 200, SimWidget.VerticalPosition.MIDDLE);
        SimWidget sw2 = new SimWidget(100, 800, 100, SimWidget.VerticalPosition.TOP);
        SimWidget sw3 = new SimWidget(50, 150, 150, SimWidget.VerticalPosition.FILL);

        LinearLayout hbox2 = new LinearLayout();
        hbox2.setColor(Color.BROWN);
        SimWidget sw4 = new SimWidget(25, 200, 400, BaseWidget.VerticalPosition.MIDDLE);
        SimWidget sw5 = new SimWidget(100, 200, 300, BaseWidget.VerticalPosition.TOP);


        LinearLayout hbox3 = new LinearLayout();
        hbox3.setColor(Color.GREEN);
        SimWidget sw6 = new SimWidget(75, 600, 100, BaseWidget.VerticalPosition.TOP);
        SimWidget sw7 = new SimWidget(50, 100, 150, BaseWidget.VerticalPosition.MIDDLE);



        hbox3.addChild(sw6);
        hbox3.addChild(sw7);

        hbox2.addChild(sw4);
        hbox2.addChild(sw5);
        hbox2.addChild(hbox3);

        root.addChild(sw1);
        root.addChild(sw2);
        root.addChild(sw3);
        root.addChild(hbox2);


        addRectangles(root);

        this.widthProperty().addListener(observable -> root.doLayout(this.getWidth(), this.getHeight()));
        this.heightProperty().addListener(observable -> root.doLayout(this.getWidth(), this.getHeight()));

    }
    public void addRectangles(BaseWidget root) {
        // add root rectangle
        getChildren().add(root.getRectangle());

        // check if child is a linear layout and add it and its children
        if (root instanceof LinearLayout) {
            for (BaseWidget child : ((LinearLayout) root).getChildren()) {
                addRectangles(child);
            }
        }
    }




}

