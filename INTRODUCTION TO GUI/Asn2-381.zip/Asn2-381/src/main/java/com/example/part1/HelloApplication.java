package com.example.part1;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        stage.setTitle("Layout Simulator");

        // Create a LayoutView
        LayoutView layoutView = new LayoutView();

        // Create a Scene using the LayoutView as the root
        Scene scene = new Scene(layoutView, 500, 400); // Adjust the scene size as needed

        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}