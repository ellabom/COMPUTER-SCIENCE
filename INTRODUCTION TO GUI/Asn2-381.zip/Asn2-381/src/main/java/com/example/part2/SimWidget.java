package com.example.part2;

import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

public class SimWidget {

    private double minWidth, maxWidth, prefHeight;
    private double myLeft, myTop, myHeight, myWidth;

    private Rectangle widgetRectangle;

    public enum VerticalPosition{
        TOP, MIDDLE, FILL
    }

    private VerticalPosition Position;

    public SimWidget(double minWidth, double maxWidth, double prefHeight, VerticalPosition position){
        this.minWidth = minWidth;
        this.maxWidth = maxWidth;
        this.prefHeight = prefHeight;

        this.Position = position;

        this.myLeft = 0;
        this.myTop = 0;
        this.myWidth = minWidth;
        this.myHeight = prefHeight;

        widgetRectangle = new Rectangle(myLeft, myTop, myWidth,myHeight);
        widgetRectangle.setFill(Color.YELLOW);
        widgetRectangle.setStroke(Color.BLACK);

    }


    // getters
    public double getMinWidth(){
        return minWidth;
    }
    public double getMaxWidth() {
        return maxWidth;
    }
    public double getPrefHeight() {
        return prefHeight;
    }
    public double getMyHeight() {
        return myHeight;
    }
    public double getMyWidth() {
        return myWidth;
    }

    //setters
    public void setPrefHeight(double prefHeight) {
        this.prefHeight = prefHeight;
    }
    public void setMaxWidth(double maxWidth) {
        this.maxWidth = maxWidth;
    }
    public void setMinWidth(double minWidth) {
        this.minWidth = minWidth;
    }
    public void setMyHeight(double myHeight) {

        this.myHeight = myHeight;
        widgetRectangle.setHeight(myHeight);
    }
    public void setMyWidth(double myWidth) {
        this.myWidth = myWidth;
        widgetRectangle.setWidth(myWidth);
    }
    public void setMyLeft(double myLeft) {
        this.myLeft = myLeft;
        widgetRectangle.setX(myLeft);
    }

    public void setMyTop(double myTop) {
        this.myTop = myTop;
        widgetRectangle.setY(myTop);
    }

    public Rectangle getWidgetRectangle(){
        return widgetRectangle;
    }
    public void doHorizontalLayout(double parcelLeft, double parcelRight){
        setMyLeft(parcelLeft);
        setMyWidth(Math.abs(parcelLeft - parcelRight));
        widgetRectangle.setWidth(myWidth);
        widgetRectangle.setX(myLeft);
    }

    public void doVerticalLayout(double parcelTop, double parcelBottom){

        switch(Position){
            case TOP :
                this.myTop = parcelTop;
                widgetRectangle.setLayoutY(parcelTop);
                break;

            case FILL :
                this.myTop = parcelTop;
                this.myHeight = Math.abs(parcelBottom - parcelTop);
                widgetRectangle.setLayoutY(myTop);
                widgetRectangle.setHeight(myHeight);
                break;

            case MIDDLE :
                double remaining = Math.abs(parcelBottom - parcelTop);
                this.myTop = parcelTop + (remaining - prefHeight)/2;
                break;

            default:
                break;

        }
        widgetRectangle.setY(myTop);
        widgetRectangle.setHeight(myHeight);

    }

}
