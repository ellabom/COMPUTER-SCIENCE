package com.example.part3;

import javafx.scene.shape.Rectangle;


public class SimWidget extends BaseWidget{


    public SimWidget(double minWidth, double maxWidth, double prefHeight, VerticalPosition Position) {

        super(minWidth, maxWidth, prefHeight, Position);
    }



    public double getMinWidth() {return super.getMinWidth();}

    public double getPrefHeight() {
        return super.getPrefHeight();
    }

    public double getMaxWidth() {
        return super.getMaxWidth();
    }

    public Rectangle getRectangle(){
        return super.getRectangle();
    }

    public double getMyWidth() {return super.getMyWidth();}

    public void doHorizontalLayout(double parcelLeft, double parcelRight){

        super.doHorizontalLayout(parcelLeft, parcelRight);

    }

    public void doVerticalLayout(double parcelTop, double parcelBottom){
        super.doVerticalLayout(parcelTop, parcelBottom);
    }


}