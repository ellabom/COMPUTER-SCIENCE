package com.example.part3;

import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import java.util.List;

public class BaseWidget {
    public enum VerticalPosition {
        TOP, MIDDLE, FILL
    }

    protected Rectangle rectangle;
    protected double minWidth;
    protected double maxWidth;
    protected double prefHeight;
    protected double myLeft;
    protected double myWidth;
    protected double myTop;
    protected double myHeight;
    protected VerticalPosition position;

    public BaseWidget(double minWidth, double maxWidth, double prefHeight, VerticalPosition position) {
        this.minWidth = minWidth;
        this.maxWidth = maxWidth;
        this.prefHeight = prefHeight;
        this.position = position;

        rectangle = new Rectangle(minWidth, prefHeight);
        rectangle.setFill(Color.YELLOW);
        rectangle.setStroke(Color.BLACK);
    }


    public double getMinWidth() {
        return minWidth;
    }

    public double getPrefHeight() {
        return prefHeight;
    }

    public double getMaxWidth() {
        return maxWidth;
    }

    public Rectangle getRectangle() {
        return rectangle;
    }

    public double getMyWidth() {
        return myWidth;
    }

    public void doHorizontalLayout(double parcelLeft, double parcelRight){

        this.myLeft = parcelLeft;
        rectangle.setLayoutX(myLeft);

        this.myWidth = parcelRight - parcelLeft;
        rectangle.setWidth(myWidth);

    }

    public void doVerticalLayout(double parcelTop, double parcelBottom) {

        switch (position) {
            case TOP:
                this.myTop = parcelTop;
                rectangle.setLayoutY(parcelTop);
                break;

            case FILL:
                this.myTop = parcelTop;
                this.myHeight = Math.abs(parcelBottom - parcelTop);
                rectangle.setLayoutY(myTop);
                rectangle.setHeight(myHeight);
                break;

            case MIDDLE:

                double remaining = Math.abs(parcelBottom - parcelTop);
                this.myTop = parcelTop + (remaining - prefHeight) / 2;
                rectangle.setLayoutY(myTop);
                break;

            default:
                break;

        }
    }

    public boolean hasChildren() {
        return false;
    }

    public List<BaseWidget> getChildren() {
        return null;
    }
}
