package com.example.part3;

import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

import java.util.ArrayList;
import java.util.List;

public class LinearLayout extends BaseWidget{
    private List<BaseWidget> children = new ArrayList<>();

    public LinearLayout() {
        super(0, 0, 0, VerticalPosition.TOP);
    }

    protected void setColor(Color linearColor){
        rectangle.setFill(linearColor);
    }

    @Override
    public boolean hasChildren(){
        return !children.isEmpty();
    }

    @Override
    public List<BaseWidget> getChildren() {
        return children;
    }

    public void addChild(BaseWidget widget) {
        children.add(widget);
    }


    public void doLayout(double width, double height) {

        if(hasChildren()) {
            doHorizontalLayout(0, width);
            doVerticalLayout(0, height);
            calculateVIS();
        }
        rectangle.setWidth(width);
        rectangle.setHeight(height);
    }


    public void doHorizontalLayout(double parcelLeft, double parcelRight) {
        double remainingWidth = Math.abs(parcelLeft - parcelRight);
        double equalAllocation = remainingWidth / children.size();

        double height = 0;
        double left = parcelLeft;

        for (BaseWidget child : children) {
            double childrenWidth = child.getMinWidth() + equalAllocation;
            childrenWidth = Math.min(childrenWidth, child.getMaxWidth());
            child.doHorizontalLayout(left, left + childrenWidth);

            height = Math.max(height, child.getPrefHeight());
            left += childrenWidth;
        }

        // Set the width of the rectangle to cover the entire available width
        rectangle.setWidth(remainingWidth);
        rectangle.setHeight(height);

    }



    public void doVerticalLayout(double parcelTop, double parcelBottom){
        for (BaseWidget child : children){
            child.doVerticalLayout(parcelTop, parcelBottom);
        }

    }
    public Rectangle getRectangle() {
        return super.getRectangle();
    }




    public void calculateVIS(){
        double visWidth = 0;
        double visHeight = 0;
        for(BaseWidget child: children){
            visWidth += child.getMinWidth();
            visHeight = Math.max(visHeight, child.getPrefHeight());
        }

        rectangle.setWidth(visWidth);
        rectangle.setHeight(visHeight);
    }



}
