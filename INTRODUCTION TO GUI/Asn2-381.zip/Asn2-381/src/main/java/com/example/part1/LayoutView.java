package com.example.part1;

import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;

public class LayoutView extends Pane {
    private LinearLayout root;

    public LayoutView(){
        root = new LinearLayout();
        root.setColor(Color.ORANGE);


        SimWidget sw1 = new SimWidget(50,200,200);
        SimWidget sw2 = new SimWidget(100,100,100);
        SimWidget sw3 = new SimWidget(150,250,150);

        root.addChild(sw1);
        root.addChild(sw2);
        root.addChild(sw3);

        root.doLayout();
        addRectangles(root);
    }

    public void addRectangles(LinearLayout root) {
        // Add layout container and child widget rectangles to the LayoutView
        getChildren().add(root.getRectangle());
        for (SimWidget child : root.getChildren()) {
            getChildren().add(child.getWidgetRectangle());
        }
    }
}
