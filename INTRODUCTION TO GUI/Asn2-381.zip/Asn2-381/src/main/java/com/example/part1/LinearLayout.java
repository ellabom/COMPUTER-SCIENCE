package com.example.part1;

import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

import java.util.ArrayList;
import java.util.List;

public class LinearLayout {

    private List<SimWidget> children;
    private Rectangle rectangle;

    public LinearLayout(){
        children = new ArrayList<>();
        rectangle = new Rectangle();
        rectangle.setStrokeWidth(3);
        rectangle.setStroke(Color.PURPLE);
    }


    protected void setColor(Color linearColor){
        rectangle.setFill(linearColor);
    }

    public void doLayout(){

        double left = 0;
        double height = 0;
        for(SimWidget child : children){
            child.setMyLeft(left);
            child.setMyTop(0);

            child.setMyWidth(child.getMinWidth());
            child.setMyHeight(child.getWidgetRectangle().getHeight());
            height = Math.max(height, child.getMyHeight());
            left += child.getMyWidth();
        }
        rectangle.setWidth(left);
        rectangle.setHeight(height);
    }


    public void addChild(SimWidget child){
        children.add(child);
    }
    public List<SimWidget> getChildren() {
        return children;
    }

    public Rectangle getRectangle() {
        return rectangle;
    }
}
