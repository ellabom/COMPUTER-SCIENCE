module com.example.demo2 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.part2 to javafx.fxml;
    opens com.example.part3 to javafx.fxml;
    exports com.example.part2;
    exports com.example.part3;
}