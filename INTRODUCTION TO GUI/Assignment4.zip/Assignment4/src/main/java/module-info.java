module com.example.assignment4 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.assignment4 to javafx.fxml;
    opens com.example.assignment4_part2 to javafx.fxml;
    opens com.example.assignment4_part3 to javafx.fxml;
    opens com.example.part4 to javafx.fxml;
    exports com.example.assignment4;
    exports com.example.assignment4_part2;
    exports com.example.assignment4_part3;
    exports com.example.part4;

}