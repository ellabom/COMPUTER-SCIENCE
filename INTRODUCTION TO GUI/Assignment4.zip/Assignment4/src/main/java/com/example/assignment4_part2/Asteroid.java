package com.example.assignment4_part2;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Asteroid {

    private double x, y, radius, angle;
    private List<Double> xPoints, yPoints;
    private double xVelocity, yVelocity, aVelocity;

    Asteroid(){
        Random rand = new Random();
        this.x = Math.random();
        this.y = Math.random();
        this.radius = 0.05 + Math.random() * 0.01;
        this.angle = 0;
        this.xVelocity = Math.random() * 0.01;
        this.yVelocity = Math.random() * 0.002;
        this.aVelocity = Math.random() * 0.005 ;

        int min = 4;
        int sections = new Random().nextInt((5)) + min;
        xPoints = new ArrayList<>();
        yPoints  = new ArrayList<>();

        // section, set new radius and add x,y home coordinated
        for(int i = 0; i < sections; i++){
            double angle =  (i * (2 * Math.PI)/sections);

            double newRadius = (Math.random() + 0.2) * this.radius;
            double xPoint = (newRadius * Math.cos(angle)) + this.x;
            double yPoint = (newRadius * Math.sin(angle)) + this.y;

            xPoints.add(xPoint);
            yPoints.add(yPoint);
        }


    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public double getAngle() {
        return angle;
    }

    public double getRadius() {
        return radius;
    }
    public List<Double> getxPoints() {
        return xPoints;
    }
    public List<Double> getyPoints() {
        return yPoints;
    }

    public void moveAsteroids() {
        // Update position based on velocities
        x += xVelocity;
        y += yVelocity;

        // Wrap-around logic for asteroids moving off-screen
        if (x < 0.0) {
            x = 1.0 + x; // Move to the opposite side of the screen
        } else if (x > 1.0) {
            x = x - 1.0; // Move to the opposite side of the screen
        }

        if (y < 0.0) {
            y = 1.0 + y; // Move to the opposite side of the screen
        } else if (y > 1.0) {
            y = y - 1.0; // Move to the opposite side of the screen
        }
    }



    public void spinAsteroids() {
        // Update angle based on angular velocity
        angle += aVelocity;
        if(angle == 360) angle = 0;
    }
}
