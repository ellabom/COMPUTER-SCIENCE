package com.example.part4;

public class Star {
    private double x;
    private double y;

    public Star(double x, double y){
        this.x = x;
        this.y = y;
    }

    public double getY() {
        return y;
    }

    public double getX() {
        return x;
    }
}
