package com.example.part4;

import javafx.animation.AnimationTimer;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;

public class MainUI extends BorderPane {

    SpaceModel model;
    SpaceView view , miniatureView;
    SpaceController controller;
    CursorView cursorView;
    InteractionModel interactionModel;
    PublishSubscriber publishSubscriber;
    ControlPanelView controlPanelView;

    public MainUI() {
        model = new SpaceModel();
        view = new SpaceView(800);
        miniatureView= new SpaceView(200);
        cursorView = new CursorView(200);
        controller = new SpaceController();
        interactionModel = new InteractionModel();
        publishSubscriber = new PublishSubscriber();
        controlPanelView = new ControlPanelView(controller);


        miniatureView.setStyle("-fx-border-color: gray;");
        cursorView.setStyle("-fx-border-color: gray;");
        controlPanelView.setStyle("-fx-border-color: gray;");

        VBox leftPanel = new VBox();
        leftPanel.getChildren().addAll(miniatureView, cursorView, controlPanelView); // Add the miniature view
        leftPanel.setStyle("-fx-border-color: #191919;");



        setCenter(view);
        setLeft(leftPanel);

        controller.setModel(model);
        controller.setiModel(interactionModel);
        model.setPublishSubscriber(publishSubscriber);
        view.setInteractionModel(interactionModel);
        miniatureView.setInteractionModel(interactionModel);
        cursorView.setInteractionModel(interactionModel);


        publishSubscriber.newChannel("create");
        publishSubscriber.newChannel("miniature");
        publishSubscriber.newChannel("select");

        publishSubscriber.addSubscribe("create", view);
        publishSubscriber.addSubscribe("miniature", miniatureView);
        publishSubscriber.addSubscribe("create", cursorView);
        publishSubscriber.addSubscribe("select", view);

        for (int i = 0; i < 10; i++) {
            model.createAsteroid(800, 800);
            model.notifySubscriber("create");
        }

        view.setOnMouseMoved(event -> {
            double x = event.getX() / view.getWidth();
            double y = event.getY() / view.getHeight();
            interactionModel.setCursorX(x);
            interactionModel.setCursorY(y);
            cursorView.draw(model.getStarField(), model.getAsteroids());
        });


        AnimationTimer timer = new AnimationTimer() {
            @Override
            public void handle(long now) {
                boolean isMoveChecked = controlPanelView.getMoveCheckBox();
                boolean isSpinChecked = controlPanelView.getSpinCheckBox();
                controller.handleAnimationTick(isMoveChecked, isSpinChecked, controlPanelView.getRotation());
                model.notifySubscriber("create");
                model.notifySubscriber("miniature");
            }
        };
        timer.start();
    }
}
