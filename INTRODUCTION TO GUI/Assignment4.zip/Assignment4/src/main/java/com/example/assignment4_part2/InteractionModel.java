package com.example.assignment4_part2;

public class InteractionModel {

    private double worldRotation = 0.0;

    public double getWorldRotation() {
        return worldRotation;
    }

    public void incrementRotation(double increase){
        worldRotation += increase;
    }
}
