package com.example.assignment4;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;

import java.util.List;

public class SpaceView extends StackPane implements Subscriber{

    Canvas canvas;
    GraphicsContext gc;
    double canvasWidth;
    double canvasHeight;


    public SpaceView(double size){
        canvasHeight = size;
        canvasWidth  = size;
        canvas = new Canvas(size, size);
        gc = canvas.getGraphicsContext2D();
        this.getChildren().add(canvas);
        this.setFocusTraversable(true);
    }

    public void draw(List<Star> starField, List<Asteroid> asteroids){
        gc.clearRect(0, 0, canvasWidth, canvasHeight);
        gc.setFill(javafx.scene.paint.Color.WHITE);
        for (Star star : starField) {

                double starX = star.getX() * canvasWidth;
                double starY = star.getY() * canvasHeight;
                gc.fillOval(starX, starY, 2, 2);
        }

        gc.setFill(Color.DARKGRAY);
        for (Asteroid asteroid : asteroids) {
            double x = asteroid.getX() * canvasWidth;
            double y = asteroid.getY() * canvasHeight;
            double radius = asteroid.getRad() * canvasWidth;
            gc.fillOval(x - radius, y - radius, radius * 2, radius * 2);
        }

    }

    @Override
    public void receiveNotification(String channel, List<Asteroid> asteroids, List<Star> starField) {
        if (channel.equals("create")) {
            draw(starField, asteroids);
        }
    }
}
