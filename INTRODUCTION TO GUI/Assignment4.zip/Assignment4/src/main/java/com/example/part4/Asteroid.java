package com.example.part4;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.PixelReader;
import javafx.scene.image.WritableImage;
import javafx.scene.paint.Color;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Asteroid {

    private double x, y, radius, angle, width, height;
    private List<Double> xPoints, yPoints;
    private double xVelocity, yVelocity, aVelocity;
    private WritableImage buffer;
    private PixelReader reader;
    private boolean isSelected;

    Asteroid(double mainWidth, double mainHeight){
        Random rand = new Random();
        this.x = rand.nextDouble();
        this.y = rand.nextDouble();

        this.y = Math.random(); // Adjust the range as needed

        this.radius = (0.03 + Math.random() * 0.03);
        this.angle = 0;
        this.xVelocity = - (Math.random() - 0.005) * 0.001; // Random xVelocity
        this.yVelocity = - (Math.random() - 0.005) * 0.001; // Random yVelocity
        this.aVelocity = (Math.random() - 0.5) * 0.01; // Random aVelocity


        int sections = new Random().nextInt((5)) + 4;
        xPoints = new ArrayList<>();
        yPoints  = new ArrayList<>();

        // section, set new radius and add x,y home coordinated
        for(int i = 0; i < sections; i++){
            double angle =  (i * (2 * Math.PI)/sections);

            double newRadius = (Math.random() + 0.2) * this.radius;
            double xPoint = (newRadius * Math.cos(angle));
            double yPoint = (newRadius * Math.sin(angle));

            xPoints.add(xPoint);
            yPoints.add(yPoint);
        }

        double[] xS = xPoints.stream().mapToDouble(Double::doubleValue).toArray();
        double[] yS = xPoints.stream().mapToDouble(Double::doubleValue).toArray();

        width = mainWidth; height = mainHeight;
        Canvas canvas = new Canvas(width, height);
        GraphicsContext gc = canvas.getGraphicsContext2D();
        buffer = new WritableImage((int)width, (int)height);
        reader = buffer.getPixelReader();


        // set bitmap to black
        gc.setFill(Color.BLACK);
        gc.fillRect(0, 0, width, height);

        gc.setFill(Color.WHITE);
        gc.translate(width/2.0, height/2.0);

        gc.fillPolygon(xS, yS, xPoints.size());
        gc.setLineWidth(0.001);
        gc.strokePolygon(xS, yS, xPoints.size());
        canvas.snapshot(null, buffer);

    }

    public boolean contains(double x, double y) {
        // Transform the location to the asteroid's reference frame
        double transX = x - this.getX() * width;
        double transY = y - this.getY() * height;

        // Apply rotation to the transformed location
        double rX = rotateX(transX, transY, Math.toRadians(this.angle));
        double rY = rotateY(transX, transY, Math.toRadians(this.angle));

        int pX = (int) (rX * buffer.getWidth());
        int pY = (int) (rY * buffer.getHeight());

        // Ensure the indices are within bounds
        if (pX >= 0 && pX < buffer.getWidth() && pY >= 0 && pY < buffer.getHeight()) {
            return reader.getColor(pX, pY).equals(Color.WHITE);
        }

        return false;
    }


    public boolean isSelected() {

        return isSelected;
    }

    // Helper methods for rotation
    public double rotateX(double x, double y, double radians) {
        return Math.cos(radians) * x - Math.sin(radians) * y;
    }

    public double rotateY(double x, double y, double radians) {
        return Math.sin(radians) * x + Math.cos(radians) * y;
    }

    public void setX(double x) {
        this.x = x;
    }
    public void setY(double y) {
        this.y = y;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public double getAngle() {
        return angle;
    }

    public double getRadius() {
        return radius;
    }
    public List<Double> getxPoints() {
        return xPoints;
    }
    public List<Double> getyPoints() {
        return yPoints;
    }

    public void moveAsteroids() {
        // Update position based on velocities
        x += xVelocity;
        y += yVelocity;

        // Wrap around if asteroid moves off-screen
        if (x > 1) {
            x = (x - 1.0);
        } else if (x < 0) {
            x = 1.0 + x;
        }
        if (y > 1) {
            y = (y - 1.0);
        } else if (y < 0) {
            y = 1.0 + y;
        }
    }


    public void spinAsteroids() {
        // Update angle based on angular velocity
        angle += aVelocity;
        if(angle == 360) angle = 0;
    }

    public void setxVelocity(double xVelocity) {
        this.xVelocity = xVelocity;
    }

    public void setyVelocity(double yVelocity) {
        this.yVelocity = yVelocity;
    }

    public void setSelected(boolean b) {
        isSelected = b;
    }
}
