package com.example.assignment4_part2;

import java.util.List;

public interface Subscriber {

    public void receiveNotification(String channel, List<Asteroid> asteroids, List<Star> stars);

}
