package com.example.assignment4;

public class Asteroid {

    private double x, y, rad;

    Asteroid(double x, double y, double rad){
        this.x = x;
        this.y  = y;
        this.rad = rad;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public double getRad() {
        return rad;
    }
}
