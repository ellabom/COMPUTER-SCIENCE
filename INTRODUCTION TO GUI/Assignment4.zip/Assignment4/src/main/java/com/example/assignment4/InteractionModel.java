package com.example.assignment4;

public class InteractionModel {
}
