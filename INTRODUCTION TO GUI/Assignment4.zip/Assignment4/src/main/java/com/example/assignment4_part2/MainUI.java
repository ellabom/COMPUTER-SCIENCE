package com.example.assignment4_part2;

import javafx.animation.AnimationTimer;
import javafx.scene.layout.StackPane;

public class MainUI extends StackPane {

    SpaceModel model;
    SpaceView view;
    SpaceController controller;
    InteractionModel interactionModel;
    PublishSubscriber publishSubscriber;

    public MainUI() {
        model = new SpaceModel();
        view = new SpaceView(800);
        controller = new SpaceController();
        interactionModel = new InteractionModel();
        publishSubscriber = new PublishSubscriber();


        controller.setModel(model);
        controller.setiModel(interactionModel);
        model.setPublishSubscriber(publishSubscriber);
        view.setInteractionModel(interactionModel);

        publishSubscriber.newChannel("create");
        publishSubscriber.addSubscribe("create", view);


        for (int i = 0; i < 10; i++) {
            model.createAsteroid();
            model.notifySubscriber("create");
        }

        this.getChildren().add(view);

        AnimationTimer timer = new AnimationTimer() {
            @Override
            public void handle(long now) {
                controller.handleAnimationTick();
                model.notifySubscriber("create");
            }
        };
        timer.start();
    }
}
