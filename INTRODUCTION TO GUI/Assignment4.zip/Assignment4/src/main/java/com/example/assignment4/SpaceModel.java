package com.example.assignment4;
import java.util.ArrayList;
import java.util.Random;

public class SpaceModel {

    private PublishSubscriber publishSubscriber;
    private ArrayList<Subscriber> subs;
    private ArrayList<Asteroid> asteroids;
    private ArrayList<Star> starField;


    public SpaceModel(){
        subs =new ArrayList<>();
        asteroids = new ArrayList<>();
        starField = new ArrayList<>();
        createStarField();
    }
    public void createAsteroid(double x, double y, double radius){
        asteroids.add(new Asteroid(x, y, radius));

    }

    public void createStarField(){
        Random random = new Random();
        for (int i = 0; i < 100; i++) {
            double starX = random.nextDouble();
            double starY = random.nextDouble();
            starField.add(new Star(starX, starY));
        }
    }

    public void setPublishSubscriber(PublishSubscriber publishSubscriber) {
        this.publishSubscriber = publishSubscriber;
    }

    public PublishSubscriber getPublishSubscriber() {
        return publishSubscriber;
    }

    public void notifySubscriber(String channel){
        publishSubscriber.publish(channel, asteroids, starField);
    }

    public ArrayList<Asteroid> getAsteroids() {
        return asteroids;
    }

    public ArrayList<Star> getStarField() {
        return starField;
    }
}
