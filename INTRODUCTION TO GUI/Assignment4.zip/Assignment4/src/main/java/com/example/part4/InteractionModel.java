package com.example.part4;

import java.util.List;

public class InteractionModel {
    private double worldRotation = 0.0;
    private boolean asteroidSelected = false;


    private double cursorX = 0;
    private double cursorY= 0;

    public double getCursorY() {
        return cursorY;
    }

    public double getCursorX() {
        return cursorX;
    }

    public void setCursorX(double cursorX) {
        this.cursorX = cursorX;
    }

    public void setCursorY(double cursorY) {
        this.cursorY = cursorY;
    }

    public boolean isWorldRotationEnabled() {
        return worldRotation > 0; // Returns if worldRotation is greater than 0
    }

    public double getWorldRotation() {
        return worldRotation;
    }

    public void incrementRotation(double increase){
        worldRotation += increase;
    }

    public void checkSelected(double mX, double mY, List<Asteroid> asteroids) {
        for (Asteroid asteroid : asteroids) {
            // Check if cursor location is within the bounds of the asteroid
            if (asteroid.contains(mX, mY)) {
                asteroid.setSelected(true); // Set the asteroid as selected

                // perform z-order by reordering
                asteroids.remove(asteroid); // Remove from the list
                asteroids.add(asteroid); // Add it to the end, moving it to the top
                asteroidSelected = true;
            } else {
                asteroid.setSelected(false); // Deselect the asteroid
            }
        }
    }

    public boolean isAsteroidSelected(){
        return asteroidSelected;
    }





}
