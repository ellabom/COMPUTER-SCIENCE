package com.example.assignment4_part2;

public class SpaceController {

    private SpaceModel model;
    private InteractionModel iModel;

    public void setiModel(InteractionModel iModel) {
        this.iModel = iModel;
    }
    public void setModel(SpaceModel model) {
        this.model = model;
    }

    public void handleAnimationTick(){
        model.moveAsteroid();
        model.spinAsteroid();

        iModel.incrementRotation(0.5);

    }
}
