package com.example.assignment4_part3;

import javafx.scene.input.MouseEvent;

public class SpaceController {

    private SpaceModel model;
    private InteractionModel iModel;
    private boolean isSpinning;
    private boolean isMoving;

    public void setiModel(InteractionModel iModel) {
        this.iModel = iModel;
    }

    public void setModel(SpaceModel model) {
        this.model = model;
    }

    public void handleAnimationTick(boolean isMoveChecked, boolean isSpinChecked, double rotationSpeed) {

        isMoving = isMoveChecked;
        isSpinning = isSpinChecked;

        if (isMoving) {
            model.moveAsteroid();
        }
        if (isSpinning) {
            model.spinAsteroid();
        }

        if (rotationSpeed > 0) {
            iModel.incrementRotation(rotationSpeed);
        }

    }


    public void toggleMovement(boolean isChecked) {
        isMoving = isChecked;
    }

    public void toggleSpin(boolean isChecked) {
        isSpinning = isChecked;
    }

    public void increaseWorldRotation(double speed){
        iModel.incrementRotation(speed);
    }

}
