package com.example.assignment4_part3;

import javafx.scene.paint.Color;

import java.util.List;

public class CursorView extends SpaceView {
    public CursorView(double size) {
        super(size);
    }

    @Override
    public void draw(List<Star> starField, List<Asteroid> asteroids) {
        gc.clearRect(0,0,canvasWidth,canvasHeight);
        zoom(asteroids);
    }


    private void zoom(List<Asteroid> asteroids) {
        gc.save();
        double zoom = 2.0; // Set your desired zoom factor

        double zoomWidth = canvasWidth / zoom;
        double zoomHeight = canvasHeight / zoom;

        double x_region = interactionModel.getCursorX() * canvasWidth - (canvasWidth - zoomWidth) / 2.0;
        double y_region = interactionModel.getCursorY() * canvasHeight - (canvasHeight - zoomHeight) / 2.0;


        x_region = Math.max(0, Math.min(x_region, canvasWidth - zoomWidth));
        y_region = Math.max(0, Math.min(y_region, canvasHeight - zoomHeight));

        gc.translate(-x_region * zoom, -y_region * zoom);
        gc.scale(zoom, zoom);

        drawAsteroids(asteroids);

        gc.restore();
    }



    private boolean isCursorOverAsteroid(Asteroid asteroid) {
        // Check if cursor position is within the bounds of the asteroid
        double cursorX = interactionModel.getCursorX();
        double cursorY = interactionModel.getCursorY();

        return cursorX >= asteroid.getX() - asteroid.getRadius() &&
                cursorX <= (asteroid.getX() + asteroid.getRadius()) &&
                cursorY >= asteroid.getY() - asteroid.getRadius() &&
                cursorY <= (asteroid.getY() + asteroid.getRadius());
    }

    @Override
    public void drawAsteroids(List<Asteroid> asteroids) {
        gc.setFill(Color.valueOf("#191919"));
        gc.setStroke(Color.GRAY); // Set the stroke color to white

        for (Asteroid asteroid : asteroids) {
            // Check if the cursor is over the current asteroid
            if (isCursorOverAsteroid(asteroid)) {

                gc.save(); // Save the current state

                // Translate to the asteroid's position
                gc.translate(asteroid.getX() * canvasWidth, asteroid.getY() * canvasHeight);

                // Scale and rotate based on the asteroid's properties
                gc.scale(canvasWidth * 2, canvasHeight * 2);
                gc.rotate(asteroid.getAngle());

                double[] xPoints = asteroid.getxPoints().stream().mapToDouble(Double::doubleValue).toArray();
                double[] yPoints = asteroid.getyPoints().stream().mapToDouble(Double::doubleValue).toArray();

                gc.fillPolygon(xPoints, yPoints, xPoints.length);
                gc.setLineWidth(0.001);
                gc.strokePolygon(xPoints, yPoints, xPoints.length);

                gc.restore(); // Restore the state
            }
        }
    }

    @Override
    public void setInteractionModel(InteractionModel interactionModel) {
        super.setInteractionModel(interactionModel);
    }
}
