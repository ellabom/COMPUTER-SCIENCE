package com.example.assignment4;

import javafx.scene.input.MouseEvent;

public class SpaceController {

    private SpaceModel model;
    private InteractionModel iModel;

    public void setiModel(InteractionModel iModel) {
        this.iModel = iModel;
    }
    public void setModel(SpaceModel model) {
        this.model = model;
    }

}
