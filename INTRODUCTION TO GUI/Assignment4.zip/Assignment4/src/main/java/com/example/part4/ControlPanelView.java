package com.example.part4;

import javafx.geometry.Insets;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.layout.VBox;

public class ControlPanelView extends VBox {

    private Slider rotation;
    private CheckBox moveCheckBox;
    private CheckBox spinCheckBox;

    public ControlPanelView(SpaceController controller){

        setSpacing(10);
        setPadding(new Insets(10));

        Label rotationLabel = new Label("Rotation Speed");
        rotation =  new Slider(0,1,0);

        Label moveLabel = new Label("Asteroid Movement");
        moveCheckBox = new CheckBox();

        Label spinLabel = new Label("Asteroid Spin");
        spinCheckBox = new CheckBox();

        this.getChildren().addAll(rotationLabel, rotation, moveLabel, moveCheckBox,
                spinLabel, spinCheckBox);

        moveCheckBox.setOnAction(event -> controller.toggleMovement(moveCheckBox.isSelected()));
        spinCheckBox.setOnAction(event -> controller.toggleSpin(spinCheckBox.isSelected()));
        rotation.valueProperty().addListener((observable, oldValue, newValue) -> {
            controller.increaseWorldRotation(newValue.doubleValue());
        });
    }

    public boolean getMoveCheckBox() {
        return moveCheckBox.isSelected();
    }
    public boolean getSpinCheckBox() {
        return spinCheckBox.isSelected();
    }
    public double getRotation() {
        return rotation.getValue();
    }
}
