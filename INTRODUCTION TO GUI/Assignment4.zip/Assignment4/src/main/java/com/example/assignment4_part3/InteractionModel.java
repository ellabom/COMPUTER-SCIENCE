package com.example.assignment4_part3;

public class InteractionModel {
    private double worldRotation = 0.0;
    private Asteroid selected;

    private double cursorX = 0;
    private double cursorY= 0;

    public double getCursorY() {
        return cursorY;
    }

    public double getCursorX() {
        return cursorX;
    }

    public void setCursorX(double cursorX) {
        this.cursorX = cursorX;
    }

    public void setCursorY(double cursorY) {
        this.cursorY = cursorY;
    }

    public double getWorldRotation() {
        return worldRotation;
    }

    public void incrementRotation(double increase){
        worldRotation += increase;
    }

}
