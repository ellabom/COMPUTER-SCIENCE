package com.example.assignment4;

import javafx.scene.layout.StackPane;

public class MainUI extends StackPane {

    public MainUI() {
        SpaceModel model = new SpaceModel();
        SpaceView view = new SpaceView(800);
        SpaceController controller = new SpaceController();
        InteractionModel interactionModel = new InteractionModel();
        PublishSubscriber publishSubscriber = new PublishSubscriber();

        controller.setModel(model);
        controller.setiModel(interactionModel);
        model.setPublishSubscriber(publishSubscriber);
        // todo:  In MainUI, create 10 asteroids using the model’s createAsteroid() method

        publishSubscriber.newChannel("create");
        publishSubscriber.addSubscribe("create", view);


        for (int i = 0; i < 10; i++) {
            double x = Math.random();
            double y = Math.random();
            double radius = Math.random() * 0.03; // Adjust radius range as needed
            model.createAsteroid(x, y, radius);

            model.notifySubscriber("create");
        }

        this.getChildren().add(view);
    }

}
