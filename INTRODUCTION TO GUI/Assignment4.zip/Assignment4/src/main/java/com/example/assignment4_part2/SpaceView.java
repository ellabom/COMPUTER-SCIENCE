package com.example.assignment4_part2;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;

import java.util.List;

public class SpaceView extends StackPane implements Subscriber {

    Canvas canvas;
    GraphicsContext gc;
    double canvasWidth;
    double canvasHeight;
    InteractionModel interactionModel;


    public SpaceView(double size){
        canvasHeight = size;
        canvasWidth  = size;
        canvas = new Canvas(size, size);
        gc = canvas.getGraphicsContext2D();
        this.getChildren().add(canvas);
        this.setFocusTraversable(true);
    }

    public void draw(List<Star> starField, List<Asteroid> asteroids){
        gc.clearRect(0, 0, canvasWidth, canvasHeight);
        gc.setFill(Color.WHITE);
        for (Star star : starField) {

                double starX = star.getX() * canvasWidth;
                double starY = star.getY() * canvasHeight;
                gc.fillOval(starX, starY, 2, 2);
        }

        gc.setFill(Color.valueOf("#4f555e"));
        gc.setStroke(Color.WHITE); // Set the stroke color to white

        for (Asteroid asteroid : asteroids) {
            double[] xPoints = asteroid.getxPoints().stream().mapToDouble(Double::doubleValue).toArray();
            double[] yPoints = asteroid.getyPoints().stream().mapToDouble(Double::doubleValue).toArray();

            gc.save(); // Save the current state

            // Translate to the asteroid's position
            gc.translate(asteroid.getX() * canvasWidth, asteroid.getY() * canvasHeight);

            // Apply world rotation
            gc.rotate(interactionModel.getWorldRotation());

            // Scale and rotate
            gc.scale(canvasWidth, canvasHeight);
            gc.rotate(asteroid.getAngle());

            // Fill and stroke the polygon
            gc.fillPolygon(xPoints, yPoints, xPoints.length);
            gc.setLineWidth(0.001);
            gc.strokePolygon(xPoints, yPoints, xPoints.length);

            gc.restore(); // Restore the  state
        }
    }

    @Override
    public void receiveNotification(String channel, List<Asteroid> asteroids, List<Star> starField) {
        if (channel.equals("create")) {
            draw(starField, asteroids);
        }
    }
    public void setInteractionModel(InteractionModel interactionModel) {
        this.interactionModel = interactionModel;
    }
}
