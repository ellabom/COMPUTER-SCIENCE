package com.example.part4;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;

import java.util.List;

public class SpaceView extends StackPane implements Subscriber {

    Canvas canvas;
    GraphicsContext gc;
    double canvasWidth;
    double canvasHeight;
    InteractionModel interactionModel;


    public SpaceView(double size){
        canvasHeight = size;
        canvasWidth  = size;
        canvas = new Canvas(size, size);
        gc = canvas.getGraphicsContext2D();
        this.getChildren().add(canvas);
        this.setFocusTraversable(true);

    }

    public void setupEvents(SpaceController controller){

        setOnMousePressed(controller::handleMousePressed);
        setOnMouseDragged(controller::handleMouseDragged);
        setOnMouseReleased(controller::handleMouseReleased);
    }

    public void draw(List<Star> starField, List<Asteroid> asteroids){
        gc.clearRect(0, 0, canvasWidth, canvasHeight);
        gc.save();

        gc.translate(canvasWidth / 2.0, canvasHeight / 2.0); // Translate to the center
        gc.rotate(interactionModel.getWorldRotation()); // Apply world rotation
        gc.translate(-canvasWidth / 2.0, -canvasHeight / 2.0); // Translate to the original position

        drawStarField(starField);
        gc.restore(); // Restore the state before drawing asteroids

        drawAsteroids(asteroids);
    }

    public void drawMiniView(List<Asteroid> asteroids){
        gc.clearRect(0 ,0, canvasWidth, canvasHeight);
        gc.save();

        gc.translate(canvasWidth / 2.0, canvasHeight / 2.0); // Translate to the center
        gc.rotate(interactionModel.getWorldRotation()); // Apply world rotation
        gc.translate(-canvasWidth / 2.0, -canvasHeight / 2.0); // Translate to the original position

        gc.restore();
        drawAsteroids(asteroids);

    }

    public void drawStarField(List<Star> starField){
        gc.setFill(Color.WHITE);
        if(starField != null) {
            for (Star star : starField) {
                double starX = star.getX() * canvasWidth;
                double starY = star.getY() * canvasHeight;
                gc.fillOval(starX, starY, 2, 2);
            }
        }
    }

    public void drawAsteroids(List<Asteroid> asteroids) {
        gc.setFill(Color.valueOf("#191919"));
        gc.setStroke(Color.GRAY); // Set the stroke color to white

        for (Asteroid asteroid : asteroids) {
            gc.save(); // Save the current state

            gc.translate(canvasWidth / 2.0, canvasHeight / 2.0); // Translate to the center
            gc.rotate(interactionModel.getWorldRotation()); // Apply world rotation
            gc.translate(-canvasWidth / 2.0, -canvasHeight / 2.0); // Translate to the original position


            // Translate to the updated position after rotation
            gc.translate(asteroid.getX() * canvasWidth, asteroid.getY() * canvasHeight);

            // Scale and rotate based on the asteroid's properties
            gc.scale(canvasWidth, canvasHeight);
            gc.rotate(asteroid.getAngle());

            double[] xPoints = asteroid.getxPoints().stream().mapToDouble(Double::doubleValue).toArray();
            double[] yPoints = asteroid.getyPoints().stream().mapToDouble(Double::doubleValue).toArray();


            gc.fillPolygon(xPoints, yPoints, xPoints.length);
            gc.setLineWidth(0.001);
            gc.strokePolygon(xPoints, yPoints, xPoints.length);


            gc.restore();
        }
    }

    @Override
    public void receiveNotification(String channel, List<Asteroid> asteroids, List<Star> starField) {
        if (channel.equals("create")) {
            draw(starField, asteroids);
        }
        if(channel.equals("miniature")){
            drawMiniView(asteroids);
        }
    }
    public void setInteractionModel(InteractionModel interactionModel) {
        this.interactionModel = interactionModel;
    }



}
