package com.example.assignment4_part3;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Asteroid {

    private double x, y, radius, angle, tx, ty;
    private List<Double> xPoints, yPoints;
    private double xVelocity, yVelocity, aVelocity;

    Asteroid(){
        Random rand = new Random();
        this.x = rand.nextDouble();
        this.y = rand.nextDouble();

        this.y = Math.random(); // Adjust the range as needed

        this.radius = (0.03 + Math.random() * 0.03);
        this.angle = 0;
        this.xVelocity = - (Math.random() - 0.005) * 0.001; // Random x velocity
        this.yVelocity = - (Math.random() - 0.005) * 0.001; // Random y velocity
        this.aVelocity = (Math.random() - 0.5) * 0.01; // Random angular velocity


        int sections = new Random().nextInt((5)) + 4;
        xPoints = new ArrayList<>();
        yPoints  = new ArrayList<>();

        // section, set new radius and add x,y home coordinated
        for(int i = 0; i < sections; i++){
            double angle =  (i * (2 * Math.PI)/sections);

            double newRadius = (Math.random() + 0.2) * this.radius;
            double xPoint = (newRadius * Math.cos(angle));
            double yPoint = (newRadius * Math.sin(angle));

            xPoints.add(xPoint);
            yPoints.add(yPoint);
        }
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public void setX(double x) {
        this.x = x;
    }

    public void setY(double y) {
        this.y = y;
    }

    public double getAngle() {
        return angle;
    }

    public double getRadius() {
        return radius;
    }
    public List<Double> getxPoints() {
        return xPoints;
    }
    public List<Double> getyPoints() {
        return yPoints;
    }

    public void moveAsteroids() {
        // Update position based on velocities
        x += xVelocity;
        y += yVelocity;

        // Wrap around if asteroid moves off-screen
        if (x > 1) {
            x = (x - 1.0);
        } else if (x < 0) {
            x = 1.0 + x;
        }
        if (y > 1) {
            y = (y - 1.0);
        } else if (y < 0) {
            y = 1.0 + y;
        }

    }

    public void setxVelocity(double xVelocity) {
        this.xVelocity = xVelocity;
    }

    public void setyVelocity(double yVelocity) {
        this.yVelocity = yVelocity;
    }

    public void spinAsteroids() {
        // Update angle based on angular velocity
        angle += aVelocity;
        if(angle == 360) angle = 0;
    }

}
