package com.example.assignment4;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class SpaceApp extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        MainUI root = new MainUI();
        root.setStyle("-fx-background-color:black;");
        Scene scene = new Scene(root);
        primaryStage.setTitle("381-a4");
        primaryStage.setScene(scene);
        primaryStage.show();
    }


    public static void main(String[] args) {
        launch();
    }

}
