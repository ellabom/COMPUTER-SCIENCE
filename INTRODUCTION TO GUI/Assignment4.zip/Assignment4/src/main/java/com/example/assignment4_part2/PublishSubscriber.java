package com.example.assignment4_part2;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PublishSubscriber {

    private Map<String, ArrayList<Subscriber>> channels;

    public PublishSubscriber(){
        this.channels = new HashMap<>();
    }

    //create new channel
    public void newChannel(String key){
        if (!channels.containsKey(key)) {
            channels.put(key, new ArrayList<>());
        }
    }

    //allow publishers to and publish to a channel
    public void publish(String channel, List<Asteroid> asteroids, List<Star> stars){
        List<Subscriber> subs = channels.get(channel);

        if(subs != null) {
            for (Subscriber sub : subs) {
                sub.receiveNotification(channel, asteroids, stars);
            }
        }
    }

    // Subscribers should have a method to receive a notification
    public void addSubscribe(String channelKey, Subscriber subscriber) {
        if (channels.containsKey(channelKey)) {
            // If the channel already exists, add the new subscriber to the existing list
            channels.get(channelKey).add(subscriber);
        } else {
            // If the channel does not exist, create a new list and add the subscriber
            ArrayList<Subscriber> subscribers = new ArrayList<>();
            subscribers.add(subscriber);
            channels.put(channelKey, subscribers);
        }
    }
}
