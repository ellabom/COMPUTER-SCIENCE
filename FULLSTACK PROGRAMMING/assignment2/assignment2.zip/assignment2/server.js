//EMMANUELLA EYO EEE917 11291003
"use strict";

// load package
const express = require("express");
const bodyParser = require("body-parser");
const fs = require("fs");
const e = require("express");

const PORT = process.env.PORT || 3002;
const HOST = "0.0.0.0";
const app = express();

app.use(bodyParser.urlencoded({ extended: true }));

app.post("/postmessage", (req, res) => {
  const topic = req.body.topic;
  const data = req.body.data;
  const timestamp = new Date().toUTCString();

  const postmsg = `${topic}; ${data}; ${timestamp}\n`;

  fs.stat("posts.txt", function (err, stat) {
    if (err == null) {
      fs.appendFile("posts.txt", postmsg, (err) => {
        if (err) console.log(err);
        console.log(`Post saved`);
      });
    } else {
      fs.writeFile("posts.txt", postmsg, (err) => {
        if (err) console.log(err);
        console.log("The file has been created!");
      });
    }
  });
});

app.listen(PORT, HOST, () => {
  console.log(`Running on http://${HOST}:${PORT}`);
});
